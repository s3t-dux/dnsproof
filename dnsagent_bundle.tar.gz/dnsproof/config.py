### config.py
from pathlib import Path

ZONE_DIR = Path("/etc/coredns/zone")
KEY_DIR = Path("/etc/coredns/keys")